
#include <stdio.h>
#include <string.h>

void process_data(char *input) {
    char buffer[64];
    strcpy(buffer, input);
    printf("Buffer: %s\n", buffer);
}
