
#include <stdio.h>
#include <string.h>

void safe_process(const char *input) {
    char buffer[64];
    if (input != NULL) {
        snprintf(buffer, sizeof(buffer), "%s", input);
        printf("Safe buffer: %s\n", buffer);
    }
}
