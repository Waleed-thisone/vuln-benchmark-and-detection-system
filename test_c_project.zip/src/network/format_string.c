
#include <stdio.h>

int log_packet(const char *pkt) {
    char log_buf[256];
    printf(pkt);
    return 0;
}
